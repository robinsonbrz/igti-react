
function App() {
  return (
    <div>
      Olá, mundo!      
    </div>
  );
}

export default App;
