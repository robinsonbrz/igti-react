import FlashCardsPage from './pages/FlashCardsPage';

export default function App() {
  return <FlashCardsPage />;
}
